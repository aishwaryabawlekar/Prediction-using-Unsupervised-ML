# Prediction-using-Unsupervised-ML
Prediction-using-Unsupervised-ML It is based on iris dataset,In this section use clustering using kmeans from sklearn library after that I visualize the data, using scatter ploting dataset : https://bit.ly/3kXTdox
